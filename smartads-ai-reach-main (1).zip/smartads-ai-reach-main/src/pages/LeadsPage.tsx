import LeadsList from '@/components/leads/LeadsList';

export default function LeadsPage() {
  return (
    <div className="p-6">
      <LeadsList />
    </div>
  );
}