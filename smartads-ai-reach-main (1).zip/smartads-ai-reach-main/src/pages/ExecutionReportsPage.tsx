import ExecutionReportsList from '@/components/reports/ExecutionReportsList';

export default function ExecutionReportsPage() {
  return (
    <div className="p-6">
      <ExecutionReportsList />
    </div>
  );
}